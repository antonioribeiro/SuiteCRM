<?php 
require_once('custom/include/Google/GoogleHelper.php');
require_once("include/utils/encryption_utils.php");
require_once('custom/modules/Schedulers/license/OutfittersLicense.php');	
require_once('modules/Configurator/Configurator.php'); 


function pre_uninstall(){
	$gh = new GoogleHelper();
	$configurator = new Configurator();
	$db_name=$configurator->config['dbconfig']['db_name'];
	//if user has completely installed repair and rebuild and perform sync and now uninstalling
	if(dbFieldExists('users','gmail_id')===true && dbFieldExists('users','gmail_pass')===true){
		//increasing limits
		set_time_limit(9000);
		ini_set('memory_limit', '2048M'); //blacklist while package scan	
		$sql = "SELECT id,user_name, gmail_id, gmail_pass FROM users WHERE deleted='0' AND status='Active'";
		$res = $GLOBALS['db']->query($sql);
		$processed=array();
		while($row = $GLOBALS['db']->fetchByAssoc($res)){
			try{
				if(!empty($row['gmail_id']) && !empty($row['gmail_pass'])){
					if (in_array(strtolower($row['gmail_id']), $processed)) {
						$GLOBALS['log']->fatal("This email (".$row['gmail_id'].") is configured in multiple users settings,skipping....");
						continue;
					}else{
						$processed[]=strtolower($row['gmail_id']);
					}
					$GLOBALS['log']->fatal('STARTED: Clean Calendar sync for: ' .$row['user_name']." , Gmail Id: ".$row['gmail_id']);
					$gh->cleanSync($row['gmail_id'], blowfishDecode(blowfishGetKey('encrypt_field'), $row['gmail_pass']), $row['id']);
					$GLOBALS['log']->fatal('COMPLETED: Clean Calendar sync for: ' .$row['user_name']." , Gmail Id: ".$row['gmail_id']);
				}
			}catch(Exception $ex){
				$GLOBALS['log']->fatal('ERROR:' . $ex->getMessage());
			}
		}
	}else{
		// user just installs package and without repair and rebuild try to uninstall
	}
}
//check in db if column exist or not
function dbFieldExists($table,$column){
	$sql="SELECT count(*) as count FROM information_schema.COLUMNS WHERE TABLE_SCHEMA='".$GLOBALS['sugar_config']['dbconfig']['db_name']."' AND TABLE_NAME = '".$table."' AND COLUMN_NAME = '".$column."'";
	$r=$GLOBALS['db']->query($sql);
	$field=$GLOBALS['db']->fetchByAssoc($r);
	if(isset($field) && isset($field['count']) && $field['count'] > 0){
		return true;
	}else{
		return false;
	}
}
?>