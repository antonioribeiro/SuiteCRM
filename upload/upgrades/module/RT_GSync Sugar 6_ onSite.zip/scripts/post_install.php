<?php

function post_install()
{	
	try{
		
		require_once('modules/Configurator/Configurator.php'); 
		$configurator = new Configurator();
		$rt_config['GOOGLE']['APP_NAME'] = 'GSync';
		$rt_config['GOOGLE']['APP_ID'] = 'AIzaSyAKaAyz0rPj722dpy0qkgY_6vcc1U2EjnQ';
		$rt_config['GOOGLE']['CLIENT_ID'] = '864924022469.apps.googleusercontent.com';
		$rt_config['GOOGLE']['CLIENT_SECRET'] = '3-FltscpNhJ4OXpQyY_B8L9_';
		$rt_config['GOOGLE']['STATE'] = $configurator->config['site_url'].'/index.php?module=Users&action=GoogleOauth';
		$rt_config['GOOGLE']['REDIRECT_URI'] = 'http://productsdemo.rolustech.com/gsync.php';
		$rt_config['GOOGLE']['SCOPES']['0'] = 'https://www.googleapis.com/auth/drive';
		$rt_config['GOOGLE']['SCOPES']['1'] = 'https://www.googleapis.com/auth/calendar';
		$rt_config['GOOGLE']['SCOPES']['2'] = 'https://www.googleapis.com/auth/contacts';
		$rt_config['GOOGLE']['SCOPES']['3'] = 'https://apps-apis.google.com/a/feeds/groups/';
		$rt_config['GOOGLE']['SCOPES']['4'] = 'https://apps-apis.google.com/a/feeds/alias/';
		$rt_config['GOOGLE']['SCOPES']['5'] = 'https://apps-apis.google.com/a/feeds/user/';
		$rt_config['GOOGLE']['SCOPES']['6'] = 'https://www.google.com/m8/feeds/';
		$rt_config['GOOGLE']['SCOPES']['7'] = 'https://www.google.com/m8/feeds/user/';

		$configurator->config=array_merge($configurator->config,$rt_config);
		if(!in_array("rt_GSync", $configurator->config['addAjaxBannedModules'])){
			$configurator->config['addAjaxBannedModules'][] = 'rt_GSync';
		}
		if(!in_array("http://productsdemo.rolustech.com/gsync.php", $configurator->config['http_referer']['list'])){
			$configurator->config['http_referer']['list'][] = 'http://productsdemo.rolustech.com/';
		}
		$configurator->handleOverride();  
		//settings for cache emails archiving
		$fieldDefs = array('name' => 'transfered','type' => 'bool','default' => '0');
		add_column_if_not_exist($configurator->config['dbconfig']['db_name'],"email_cache","transfered", "tinyint(1) NOT NULL DEFAULT '0'",$fieldDefs);
		//GSync- Calendar
		if(createJOB('GSync- Calendar','function::googleCalenderSync','*/5::*::*::*::*')===true){
			$GLOBALS['log']->fatal('GSync- Calendar job created');
		}
		//TODO
		// if(createJOB('GSync- Calendar [Recurrence]','function::googleCalenderRecurringSync','0::0::*/3::*::*','Active')===true){
			// $GLOBALS['log']->fatal('GSync- Calendar [Recurrence] job created');
		// }
		//GSync- Contacts
		if(createJOB('GSync- Contacts','function::googleContactsSync','*/5::*::*::*::*')===true){
			$GLOBALS['log']->fatal('GSync- Contacts job created');
		}
		//GSync- Drive
		if(createJOB('GSync- Drive','function::googleDriveSync','*/5::*::*::*::*')===true){
			$GLOBALS['log']->fatal('GSync- Drive job created');
		}
		//GSync- Archive Emails
		if(createJOB('GSync- Archive Emails','function::importCacheEmails','*/10::*::*::*::*')===true){
			$GLOBALS['log']->fatal('GSync- Archive Emails job created');
		}
		refreshSettings();
		// notify_support($configurator->config['GOOGLE']['REDIRECT_URI'],$configurator);
		redirectTolicensePage(10);
		$GLOBALS['log']->fatal("Google Sync installed successfully...");
		
	}catch(Exception $e){
		$GLOBALS['log']->fatal("Error: ".$e->getMessage());
	}	
}

function add_column_if_not_exist($db_name,$table, $column, $column_attr = "VARCHAR( 255 ) NULL",$fieldDefs = array() ){
	if(dbFieldExists($table,$column)!==true){
		try{
			//$GLOBALS['db']->query("ALTER TABLE $table ADD $column  $column_attr");
			$GLOBALS['db']->addColumn($table,$fieldDefs);
		}catch(Exception $e){
			$GLOBALS['log']->fatal("Error: ".$e->getMessage());
		}
	}
}

function notify_support($uri,$configurator){
	try{
		if(isset($configurator->config['gsync_email_sent']) && $configurator->config['gsync_email_sent']==1){
			$GLOBALS['log']->fatal("GSync redirect URI email already sent");
			redirectTolicensePage(10);
		}else{
			require_once("modules/Emails/Email.php");
			$support_address='support@rolustech.com';
			$support_address_cc='junaid.usman@rolustech.com';
			$subject =  'GSync: Add Redirect URI';
			$bodyHTML= "<p>hi,<br /><br />We have installed GSync successfully,<br />please add following URL as redirect URI to Google APIs console <br />$uri <br /><br />Thanks<p>";
			$body=wordwrap($bodyHTML, 900);
			// Email Settings
			$mailSettings = array(
				'sendBcc' => '',
				'sendCc' => $support_address_cc,
				'sendTo' => $support_address,
				'attachments' => array(),
				'fromAccount' => '', // the email setting ID of the current user
				'saveToSugar' => true,
				'sendSubject' => $subject,
				);
			$_REQUEST['sendDescription'] = htmlentities($body);
			$email = new Email();
			$email->email2init();
			//sending email
			if( $email->email2Send($mailSettings) )
			{
				$configurator->config['gsync_email_sent']=1;
				$configurator->handleOverride();
				$GLOBALS['log']->fatal("Email has been sent to $support_address.");
				redirectTolicensePage(1);
			}else{
				$GLOBALS['log']->fatal("Unable to send Email to $support_address ,you have to send email mannually to this address to configure redirect uri for GOOGLE Drive your redirect URI is $uri");
				redirectTolicensePage(0);
			}
		}
	}catch(Exception $e){
		$GLOBALS['log']->fatal("Email Error: ".$e->getMessage());
		redirectTolicensePage(0);
	}	
}

function createJOB($name,$job,$job_interval){
	$scheduler = BeanFactory::getBean('Schedulers');
	$scheduler->retrieve_by_string_fields(array('job' => $job,'deleted' => '0' ));
	//if job already created do nothing just return with false
	if(!empty($scheduler->id)){
		return false;
	}
	$scheduler->name = $name;
	$scheduler->job = $job;
	$scheduler->date_time_start = '2005-01-01 00:00:00';
	$scheduler->job_interval = $job_interval;
	$scheduler->status = 'Inactive';
	$scheduler->catch_up = '1';
	if($scheduler->save()){
		return true;
	}
	return false;
}

function refreshSettings(){
	//refresh settings on installation
	$sql = "UPDATE users set ";
	if(dbFieldExists('users','lastsync_calendar')===true){
		$sql.= "lastsync_calendar='2013-01-01 01:01:01'";
	}
	if(dbFieldExists('users','lastsync_contacts')){
		$sql.= ",lastsync_contacts='2013-01-01 01:01:01'";
	}
	if(dbFieldExists('users','lastsync_drive')===true){
		$sql.= ",lastsync_drive='2013-01-01 01:01:01'";
	}
	if(dbFieldExists('users','gdrive_refresh_code')===true){
		$sql.= ",gdrive_refresh_code=''";
	}
	if($sql != "UPDATE users set "){
		$res = $GLOBALS['db']->query($sql);
	}
	
}

function dbFieldExists($table,$column){
		global $db;
		   $cols =  $db->get_columns($table);
        //if(isset($field) && isset($field['count']) && $field['count'] > 0){
        if (is_array($cols))
        {
            if(isset($cols[$column])){
                    return true;
            }
            else
            {
                return false;
            }
        }
        else{
            return false;
        }
}

function redirectTolicensePage($email_sent=10){
	if($email_sent==10){
		echo "<script type='text/javascript'>window.location='index.php?module=Schedulers&action=license';</script>";
	}elseif($email_sent==1){
		echo "<script type='text/javascript'>window.location='index.php?module=Schedulers&action=license&email_sent=1';</script>";
	}elseif($email_sent==0){
		echo "<script type='text/javascript'>window.location='index.php?module=Schedulers&action=license&email_sent=0';</script>";
	}
}

?>

