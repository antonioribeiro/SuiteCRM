<?php
function refreshSettings(){
	//refresh settings on installation
	$sql = "UPDATE users set ";
	if(dbFieldExists('users','lastsync_calendar')===true){
		$sql.= "lastsync_calendar='2013-01-01 01:01:01'";
	}
	if(dbFieldExists('users','lastsync_contacts')){
		$sql.= ",lastsync_contacts='2013-01-01 01:01:01'";
	}
	if(dbFieldExists('users','lastsync_drive')===true){
		$sql.= ",lastsync_drive='2013-01-01 01:01:01'";
	}
	if(dbFieldExists('users','gdrive_refresh_code')===true){
		$sql.= ",gdrive_refresh_code=''";
	}
/*
	if(dbFieldExists('users','gmail_id')===true){
		$sql.= ",gmail_id=''";
	}
	if(dbFieldExists('users','gmail_pass')===true){
		$sql.= ",gmail_pass=''";
	} */
	if($sql != "UPDATE users set "){
		$res = $GLOBALS['db']->query($sql);
	}
}

try{
	refreshSettings();
	$GLOBALS['log']->fatal("Google Sync uninstalled successfully...");
}catch(Exception $e){
	$GLOBALS['log']->fatal("Error: ".$e->getMessage());
}

?>
