<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
global $mod_strings;
$module_menu = Array(
	Array("index.php?module=rt_GSync&action=settings",$mod_strings['LBL_PREFRENCES'],"rt_GSync", 'rt_GSync'),
);