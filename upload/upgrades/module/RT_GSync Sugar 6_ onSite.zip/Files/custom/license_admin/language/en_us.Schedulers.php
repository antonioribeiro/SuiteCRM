<?php
$mod_strings['LBL_GMAILLICENSEADDON'] = 'RT GSync License Add-on';
$mod_strings['LBL_GMAILLICENSEADDON_LICENSE_TITLE'] = 'License Configuration';
$mod_strings['LBL_GMAILLICENSEADDON_LICENSE'] = 'Manage and configure the license for RT GSync';
$mod_strings['LBL_GSYNC_CONFIGURE_USERS_TITLE'] = 'RT GSync Users Configuration';
$mod_strings['LBL_GSYNC_CONFIGURE_USERS'] = 'Manage and configure users for RT GSync';