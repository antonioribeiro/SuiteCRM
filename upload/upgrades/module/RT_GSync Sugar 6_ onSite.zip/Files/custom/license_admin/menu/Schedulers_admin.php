<?php
$admin_option_defs=array();
$admin_option_defs['Administration']['samplelicenseaddon_info']= array('License','LBL_GMAILLICENSEADDON_LICENSE_TITLE','LBL_GMAILLICENSEADDON_LICENSE','./index.php?module=Schedulers&action=license');
$admin_option_defs['Administration']['gsync_configure_users']= array('rt_GSync','LBL_GSYNC_CONFIGURE_USERS_TITLE','LBL_GSYNC_CONFIGURE_USERS','./index.php?module=rt_GSync&action=configureUsers');
$admin_group_header[]= array('LBL_GMAILLICENSEADDON','',false,$admin_option_defs, '');