<?php

$outfitters_config = array(
	'shortname' => 'gmail-sync',
	'public_key' => '7b4c3b4e9155cb248eea1ef0a8c790ce,0ec4c142453acb8fd66d92dd6018ba0c',
	'api_url' => 'https://www.sugaroutfitters.com/api/v1',
	'validate_users' => true,
	'validation_frequency' => 'daily',
	'continue_url' => 'index.php?module=rt_GSync&action=configureUsers', 
);

