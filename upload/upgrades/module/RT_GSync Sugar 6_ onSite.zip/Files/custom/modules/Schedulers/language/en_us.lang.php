<?php
$mod_strings['LBL_GOOGLECALENDERSYNC'] = 'RT GSync- Calendar';
$mod_strings['LBL_GOOGLECONTACTSSYNC'] = 'RT GSync- Contacts';
$mod_strings['LBL_GOOGLEDRIVESYNC']    = 'RT GSync- Drive';
$mod_strings['LBL_IMPORTCACHEEMAILS']  = 'RT GSync- Archive Emails';
$mod_strings['LBL_GOOGLECALENDERRECURRINGSYNC']  = 'RT GSync- Calendar [recurrence]';
?>