<?php
$mod_strings['LBL_GMAIL_ID'] = "Gmail ID";
$mod_strings['LBL_GMAIL_PASS'] = "Gmail Password";
$mod_strings['LBL_GOOGLE_ACCOUNT'] = "Google Account Information";
?>