<?php

$hook_array['before_save'][] = Array(100, 'Handling gcontact_id for Contacts:Google Sync', 'custom/include/Google/google_hook.php','GoogleHook', 'geventHandler'); 
?>