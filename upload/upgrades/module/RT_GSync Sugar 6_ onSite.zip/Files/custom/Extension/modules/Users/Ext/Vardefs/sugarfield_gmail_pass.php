<?php
$dictionary["User"]["fields"]["gmail_pass"] = array (
	'name' => 'gmail_pass',
	'vname' => 'LBL_GMAIL_PASS',
	'dbType' => 'varchar',
	'type'=> 'password',
	'len' => 200,
	'reportable'=>false,
	'massupdate' => false,
	'importable' => 'false',
);