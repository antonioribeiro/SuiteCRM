<?php
$dictionary["Call"]["fields"]['gevent_id'] = array (
	'name'=>'gevent_id',
	'rname'=>'name',
	'vname' => 'LBL_GEVENT_ID',
	'type' => 'varchar',
	'reportable'=>false,
	'massupdate' => false,
	'importable' => 'false',
	'studio' => false,
);