<?php
 
$hook_array['before_save'][] = Array(100, 'Handling gevent_id for Tasks:Google Calendar Sync', 'custom/include/Google/google_hook.php','GoogleHook', 'geventHandler'); 
?>