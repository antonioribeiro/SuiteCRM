<?php
$dictionary["User"]["fields"]['lastsync_drive'] = array(
	'name' => 'lastsync_drive',
	'vname' => 'LBL_LASTSYNC_DRIVE',
	'type' => 'datetime',
	'reportable'=>false,
	// 'massupdate' => false,
	'importable' => 'false',
	'studio' => false,
	'default'=> '2013-01-01 01:01:01',   
);