<?php
$dictionary["User"]["fields"]['lastsync_calendar'] = array(
	'name' => 'lastsync_calendar',
	'vname' => 'LBL_LASTSYNC_CALENDAR',
	'type' => 'datetime',
	'reportable'=>false,
	// 'massupdate' => false,
	'importable' => 'false',
	'studio' => false,
	'default'=> '2013-01-01 01:01:01',
);