<?php
$dictionary["Contact"]["fields"]['gcontact_id'] = array (
	'name'=>'gcontact_id',
	'rname'=>'name',
	'vname' => 'LBL_GCONTACT_ID',
	'type' => 'varchar',
	'reportable'=>false,
	'massupdate' => false,
	'importable' => 'false',
	'studio' => false,
);
	