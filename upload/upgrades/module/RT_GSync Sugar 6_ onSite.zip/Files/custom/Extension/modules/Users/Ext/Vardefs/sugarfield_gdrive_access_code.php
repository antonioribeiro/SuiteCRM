<?php
$dictionary["User"]["fields"]["gdrive_access_code"] = array (
	'name' => 'gdrive_access_code',
	'vname' => 'LBL_GDRIVE_ACCESS_CODE',
	'type' => 'varchar',
	'len' => 300,
	'reportable'=>false,
	'massupdate' => false,
	'importable' => 'false',
	'studio' => false,
);