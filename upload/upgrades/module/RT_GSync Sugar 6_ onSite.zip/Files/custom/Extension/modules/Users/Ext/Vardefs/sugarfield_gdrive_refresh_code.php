<?php
$dictionary["User"]["fields"]["gdrive_refresh_code"] = array (
	'name' => 'gdrive_refresh_code',
	'vname' => 'LBL_GDRIVE_REFRESH_CODE',
	'type' => 'varchar',
	'len' => 300,
	'reportable'=>false,
	'massupdate' => false,
	'importable' => 'false',
	'studio' => false,
);