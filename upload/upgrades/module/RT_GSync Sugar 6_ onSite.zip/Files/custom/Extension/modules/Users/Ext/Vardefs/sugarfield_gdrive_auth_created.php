<?php
$dictionary["User"]["fields"]["gdrive_auth_created"] = array (
	'name' => 'gdrive_auth_created',
	'vname' => 'LBL_GDRIVE_AUTH_CREATED',
	'type' => 'int',
	'reportable'=>false,
	'massupdate' => false,
	'importable' => 'false',
	'studio' => false,
);