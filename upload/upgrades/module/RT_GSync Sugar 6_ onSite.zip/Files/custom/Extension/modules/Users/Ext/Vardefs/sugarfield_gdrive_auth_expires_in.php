<?php
$dictionary["User"]["fields"]["gdrive_auth_expires_in"] = array (
	'name' => 'gdrive_auth_expires_in',
	'vname' => 'LBL_GDRIVE_AUTH_EXPIRES_IN',
	'type' => 'int',
	'reportable'=>false,
	'massupdate' => false,
	'importable' => 'false',
	'studio' => false,
);