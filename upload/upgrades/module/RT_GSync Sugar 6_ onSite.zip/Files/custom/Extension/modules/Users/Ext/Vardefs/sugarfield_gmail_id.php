<?php
$dictionary["User"]["fields"]["gmail_id"] = array (
	'name' => 'gmail_id',
	'vname' => 'LBL_GMAIL_ID',
	'type' => 'varchar',
	'len' => 200,
	'reportable'=>false,
	'massupdate' => false,
	'importable' => 'false',
);