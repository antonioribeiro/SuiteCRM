<?php	
//added to handle invitees
$dictionary["Meeting"]["fields"]['invitee_email_addresses'] = array (
	'name'=>'invitee_email_addresses',
	'rname'=>'name',
	'vname' => 'LBL_INVITEE_EMAIL_ADDRESSES',
	'type' => 'text',
	'reportable'=>false,
	'massupdate' => false,
	'importable' => 'false',
	'studio' => false,
);