<?php
$dictionary["Document"]["fields"]["gdrive_id"] = array (
	'name' => 'gdrive_id',
	'vname' => 'LBL_GDRIVE_ID',
	'type' => 'varchar',
	'len' => 300,
	'reportable'=>false,
	'massupdate' => false,
	'importable' => 'false',
	'studio' => false,
);