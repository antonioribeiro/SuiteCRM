<?php
//all day event
$dictionary["Call"]["fields"]['allday'] = array (
	'name'=>'allday',
	'vname' => 'LBL_IS_ALLDAY',
	'type' => 'bool',
	'default' => 0,
	'reportable'=>false,
	'massupdate' => false,
	'importable' => 'false',
	'studio' => false,
);