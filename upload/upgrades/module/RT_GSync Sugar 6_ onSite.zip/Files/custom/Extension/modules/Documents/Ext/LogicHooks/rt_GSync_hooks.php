<?php
 
$hook_array['before_save'][] = Array(1, 'Handling gdrive_id for Documents:Google Drive Sync', 'custom/include/Google/google_hook.php','GoogleHook', 'geventHandler'); 
?>