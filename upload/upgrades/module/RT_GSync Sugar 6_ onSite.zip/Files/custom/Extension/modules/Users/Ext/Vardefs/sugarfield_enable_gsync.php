<?php
//added for cleanup process
$dictionary["User"]["fields"]['enable_gsync'] = array (
	'name'=>'enable_gsync',
	'vname' => 'LBL_ENABLE_GSYNC',
	'type' => 'bool',
	'default' => false,
	'reportable'=>false,
	'massupdate' => false,
	'importable' => 'false',
	'studio' => false,
);