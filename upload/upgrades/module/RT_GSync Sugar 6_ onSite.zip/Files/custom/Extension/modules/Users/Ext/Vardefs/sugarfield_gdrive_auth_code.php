<?php
$dictionary["User"]["fields"]["gdrive_auth_code"] = array (
	'name' => 'gdrive_auth_code',
	'vname' => 'LBL_GDRIVE_AUTH_CODE',
	'type' => 'varchar',
	'len' => 300,
	'reportable'=>false,
	'massupdate' => false,
	'importable' => 'false',
	'studio' => false,
);