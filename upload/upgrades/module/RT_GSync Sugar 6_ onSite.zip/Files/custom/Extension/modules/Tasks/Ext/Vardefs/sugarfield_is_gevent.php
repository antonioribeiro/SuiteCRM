<?php	
//added for cleanup process	
$dictionary["Task"]["fields"]['is_gevent'] = array (
	'name'=>'is_gevent',
	'vname' => 'LBL_IS_GEVENT',
	'type' => 'bool',
	'default' => '0',
	'reportable'=>false,
	'massupdate' => false,
	'importable' => 'false',
	'studio' => false,
);