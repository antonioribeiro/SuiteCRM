<?php
$dictionary["User"]["fields"]['lastsync_contacts'] = array(
	'name' => 'lastsync_contacts',
	'vname' => 'LBL_LASTSYNC_CONTACTS',
	'type' => 'datetime',
	'reportable'=>false,
	// 'massupdate' => false,
	'importable' => 'false',
	'studio' => false,
	'default'=> '2013-01-01 01:01:01',   
);