<?php
$entry_point_registry['acceptDecline'] = array(
'file' => 'custom/modules/Contacts/AcceptDecline.php',
'auth' => false
);
